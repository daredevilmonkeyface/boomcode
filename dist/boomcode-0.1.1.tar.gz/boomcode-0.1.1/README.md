Hello, I am daredevilmonkeyface (AKA daredevilmonke), and am a begginer in python. I thought that it would be cool if someone could prank their friend with just a line of code. That would be great! But still, keep  in mind I am a beginner and could not make this any better (mabye I could add more functions). Thank you for using this package! 🫠🐁





https://github.com/daredevilmonkeyface/boomcode
This project is licensed under the [MIT License](./LICENSE).